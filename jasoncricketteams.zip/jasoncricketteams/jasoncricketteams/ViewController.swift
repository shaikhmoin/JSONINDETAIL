//
//  ViewController.swift
//  jasoncricketteams
//
//  Created by MACOS on 6/21/17.
//  Copyright © 2017 king. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var finalarr :[Any] = [ ]
    var final = [String]()


    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.teams&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback=")
        do {
            let data = try Data(contentsOf: url!)
            
            do {
                let dic = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                
                let dic1 = dic["query"] as! [String:Any]
                let dic2 = dic1["results"] as! [String:Any]
                let arr = dic2["Team"] as! [[String:Any]]
                
                for item in arr
                {
                    finalarr.append(item)
                 
                    var item1 = item["TeamId"] as! [String:Any]
                    
                    final.append(item1["content"] as! String)
                    
                }

               
            } catch  {
                
            }
            
        } catch  {
            
        }
        
        //print(finalarr)
        // Do any additional setup after loading the view, typically from a nib.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finalarr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        let dicfinal = finalarr[indexPath.row] as! [String:Any]
        cell?.textLabel?.text = dicfinal["TeamName"] as! String?
        cell?.detailTextLabel?.text = final[indexPath.row]
        

        
        return cell!
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

